(function($) {
	$(function() {
		$('#datos, ul').dropdown();
	});
}(jQuery));