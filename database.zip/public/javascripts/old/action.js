(function($) {
	$(function() {
		$('#unico, ul').dropdown();
	});
}(jQuery));