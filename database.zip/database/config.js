// var config = {
// 	host     : '10.162.10.100',
// 	user     : 'user1',
// 	password : 'Colombia1+',
// 	database : 'inventario_digitex',
// 	dateStrings : true
// }

 var config = {
 	host     : 'localhost',
    user     : 'app',
    password : 'S4t3l1t4l*16',
 	database : 'inventario_digitex',
    dateStrings : true
 }

//var config = {
//	host     : 'localhost',
//  user     : 'root',
//  password : 'S4t3l1t4l*16',
//  database : 'inventario_digitex',
//  dateStrings : true
//}

module.exports = config